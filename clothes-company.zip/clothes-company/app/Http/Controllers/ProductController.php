<?php

namespace App\Http\Controllers;
use App\Size;
use App\Color;
use App\Product;
use App\Category;
use Illuminate\Http\Request;

use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $categories=Category::all();
        $sizes=Size::all();
        $colors=Color::all();
        $products=Product::when($request->search,function($q) use($request){
            return $q->where('name','like','%'. $request->search .'%');
        })->latest()->paginate(3);
        return view ('products.index',compact('products','sizes','colors','categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories=Category::all();
        return view('products.create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'category_id'=>'required',
            'code'=>'required',
            'name'=>'required',
            'image'  =>'image',
            'sale_price'=>'required',
            'stock'=>'required',
            'size'=>'required|min:1',
            'color'=>'required|min:1',
            'size.0'=>'required',
            'color.0'=>'required',   
        ]);
        $request_data=$request->all();
       if($request->image){
           Image::make($request->image)->resize(300, null, function ($constraint) {
               $constraint->aspectRatio();
           })->save(public_path('uploads/products_images/'. $request->image->hashName()));
           $request_data['image']=$request->image->hashName();
       }
       $product = Product::create($request_data);
       $sizes=$request->size;
       $product_id = $product->id;
       foreach($sizes as $size){
        Size::create([
        'product_id' => $product->id,
        'size' => $size,
        ]);
       }
        $colors=$request->color;
        $product_id = $product->id;
        foreach($colors as $color){
         Color::create([
         'product_id' => $product->id,
         'color' => $color,
         ]);
        
       }
       //dd($product->id);
       //Product::create($request_data);
       session()->flash('success',__('Added_Succefully'));
        return redirect()->route('dashboard.products.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        $sizes=Size::all();
        $colors=Color::all();
        return view('products.edit',compact('product','sizes','colors'));
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'code'=>'required',
            'name'=>'required',
            'image'  =>'image',
            'sale_price'=>'required',
            'stock'=>'required',
            'size'=>'required|min:1',
            'color'=>'required|min:1',
            'size.0'=>'required',
            'color.0'=>'required',
              
        ]);
        $request_data=$request->all();
        if($request->image){
            if($product->image !='default.jpg'){
             Storage::disk('public_uploads')->delete('/products_images/' .$product->image);
             Image::make($request->image)->resize(300, null, function ($constraint) {
                 $constraint->aspectRatio();
             })->save(public_path('uploads/products_images/'. $request->image->hashName()));
         }
             $request_data['image']=$request->image->hashName(); 
           
        }
        $sizes=$request->size;
        $product_id = $product->id;
        //dd($product->id);
        foreach($sizes as $size){
            //dd($product->id);
        Size::find($product_id )->update([
            'size' => $size,
        ]);
        }
        //dd($product->id);
        Product::find($product->id)->update($request->all());
        session()->flash('success',__('Updated_Succefully'));
        return redirect()->route('dashboard.products.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        if($product->image !='default.jpg'){
            Storage::disk('public_uploads')->delete('/products_images/' .$product->image);
        }
        $product->delete();
        session()->flash('success',__('Deleted_Succefully'));
        return redirect()->route('dashboard.products.index');
    }
}
