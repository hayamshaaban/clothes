<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'code','name','image','sale_price','stock','category_id'

    ];
    protected $appends=['image_path'];

    public function getImagePathAttribute(){
        return asset('uploads/products_images/'.$this->image);
    }
    public function getNameAttribute($value){
        return ucfirst($value);
    }
    public function sizes()
    {
     return $this->hasMany('App\Size');
    }
    public function colors()
    {
     return $this->hasMany('App\Color');
    }
    public function category(){
        return $this->belongsTo('App\Category');
    }
}
