<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <section class="content-header">

            <h1>Dashboard</h1>

            <ol class="breadcrumb">
                <li class="active"><i class="fa fa-dashboard"></i>Dashboard</li>
            </ol>
        </section>

        <section class="content">

            <div class="row">
                 
                 <div class="col-lg-3 col-xs-6">
                    <div class="small-box bg-aqua">
                        <div class="inner">

                            <h3>Categories</h3>
                        </div>
                        <div class="icon">
                            <i class="ion ion-bag"></i>
                        </div>
                        <a href="<?php echo e(route('dashboard.categories.index')); ?>" class="small-box-footer">Read more <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-3 col-xs-6">
                    <div class="small-box bg-green">
                        <div class="inner">
                            <h4>Clothes's Products</h4>
                        </div>
                        <div class="icon">
                            <i class="ion ion-stats-bars"></i>
                        </div>
                    <a href="<?php echo e(route('dashboard.products.index')); ?>" class="small-box-footer">Read more <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                

            </div><!-- end of row -->

            
            

        </section><!-- end of content -->

    </div><!-- end of content wrapper -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clothes-company\resources\views/index.blade.php ENDPATH**/ ?>