<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <section class="content-header">

            <h1 ><?php echo app('translator')->get('Products'); ?></h1>

            <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                <li class="active">Products</li>

            </ol>
        </section>

        <section class="content">

                <div class="box box-primary">
                    <div class="box-header with border">
                        <h3 class="box-title" style="margin-bottom:15px">Products</h3>
                    <form action="<?php echo e(route('dashboard.products.index')); ?>" method="get" >
                            <div class="row ">
                                <div class="col-md-4">
                                 <input type="text" name="search" class="form-control" placeholder="search">

                                </div>


                                <div class="col-md-4">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>Search</button>
                                   
                                        <a href="<?php echo e(route('dashboard.products.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i>Add Product</a>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="box-body">
                       <?php if($products->count()>0): ?>
                       <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Category</th>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Size</th>
                                    <th>colors</th>
                                    <th>Price</th>
                                    <th>stock</th>
                                
                                    <th><?php echo app('translator')->get('Action'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($product->category->name); ?></td>
                                    <td><?php echo e($product->code); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><img src="<?php echo e($product->image_path); ?>" style="width: 100px;" class="img-thumbnail"></td>
                                    <td>
                                    <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($size->size); ?>

                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(str_replace('','/',$color->color)); ?>

                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                 
                                    <td><?php echo e($product->sale_price); ?></td>
                                    <td><?php echo e($product->stock); ?></td>

                                    <td>
                                   
                                    <a href="<?php echo e(route('dashboard.products.edit',$product->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i>Edit</a>
                                    
                                    
                                       <form action="<?php echo e(route('dashboard.products.destroy',$product->id)); ?>"  method="POST" style="display:inline">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('delete')); ?>

                                            <button type="submit" class="btn btn-danger delete btn-sm"><i class="fa fa-trash"></i>Delete</button>
    
                                        </form>
                        
                                   
                                    </td>
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                        
                        <?php echo e($products->links()); ?>

                        <?php else: ?>
                    <h2>Not_products_found</h2>
                    <?php endif; ?>
                
                     </div>
                </div>
        </section>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clothes-company\resources\views/products/index.blade.php ENDPATH**/ ?>