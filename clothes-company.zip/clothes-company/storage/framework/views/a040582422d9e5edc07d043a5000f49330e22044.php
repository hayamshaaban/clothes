<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <section class="content-header">

            <h1>Products</h1>

        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="<?php echo e(route('dashboard.products.index')); ?>">Products</a></li>
            <li class="active"> Add Product</li>
            
        </ol>
        </section>

        <section class="content">

 <div class="box box-primary">
               <div class="box-header">
                   <h3 class="box-title">Add</h3>
               </div>
               <div class="box-body">
                <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
               <form action="<?php echo e(route('dashboard.products.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('post')); ?>


                <div class="form-group">
                    <label><?php echo app('translator')->get('site.categories'); ?></label>
                    <select name="category_id" class="form-control">
                    <option value="">all.categories</option>
                
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id')==$category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>

                <div class="form-group">
                    <label>Code</label>
                <input type="text" name="code"  class="form-control" value="<?php echo e(old('code')); ?>">

                </div>

               
                <div class="form-group">
                        <label>Name</label>
                <input type="text" name="name"  class="form-control" value="<?php echo e(old('name')); ?>">
   
                </div>
              
                   
                    
               
            
            
            <div class="form-group">
                    <label>Image</label>
                    <input type="file" name="image" placeholder="image" class="form-control image">

            </div>
            <div class="form-group">
            <img src="<?php echo e(asset('uploads/products_images/default.jpg')); ?>" style="width: 100px;" class="img-thumbnail image-preview" alt=""> 

            </div>

            
            
        <div class="form-group">
            <label>Size</label>
            
            <div class="nav-tabs-custom">
                <?php
                   $sizes=['xxxl','xxl','xl','L','M','S']
                ?>

                        <div class="tab-content" id="pills-tabContent">
                          <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label><input type="checkbox" name="size[]" value="<?php echo e($size); ?>"><?php echo e($size); ?></label>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                        </div>
                           
                            
            </div>
        </div>

        
        
        <div class="form-group">
            <label>Colors</label>
            
            <div class="nav-tabs-custom">
                <?php
                   $colors=['All Colors','Black','White','Red','Brown','Other']
                ?>

                        <div class="tab-content" id="pills-tabContent">
                          <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label><input type="checkbox" name="color[]" value="<?php echo e($color); ?>"><?php echo e($color); ?></label>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                        </div>
                           
                            
            </div>
        </div>
            
    
          
            <div class="form-group">
                    <label>sale price</label>
                    <input type="number" name="sale_price" step="0.01" value="<?php echo e(old('sale_price')); ?>" class="form-control">

            </div>
        
            <div class="form-group">
                    <label>stock</label>
                    <input type="number" name="stock"  class="form-control" value="<?php echo e(old('stock')); ?>">

            </div>

            


                        <div class="form-group">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i>Add Product</button>
                        </div>
    

              
                

           

            </div> 
        </div>
    </div> 
                </div> <!--end of body-->
           </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clothes-company\resources\views/products/create.blade.php ENDPATH**/ ?>