<aside class="main-sidebar">

    <section class="sidebar">

       

     <ul class="sidebar-menu" data-widget="tree">
       
     <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-th"></i><span>Dashboard</span></a></li>
     
        <li><a href="<?php echo e(route('dashboard.products.index')); ?>"><i class="fa fa-th"></i><span>Products</span></a></li>
       
        <li><a href="<?php echo e(route('dashboard.categories.index')); ?>"><i class="fa fa-book"></i><span>Categories</span></a></li>
     
            
           
            

        </ul>
  
       
    
    </section>

</aside>

<?php /**PATH C:\xampp\htdocs\clothes-company\resources\views/layouts/dashboard/_aside.blade.php ENDPATH**/ ?>