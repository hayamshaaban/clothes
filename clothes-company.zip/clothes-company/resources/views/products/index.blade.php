@extends('layouts.dashboard.app')

@section('content')

    <div class="content-wrapper">

        <section class="content-header">

            <h1 >@lang('Products')</h1>

            <ol class="breadcrumb">
            <li><a href="{{route('dashboard.index')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                <li class="active">Products</li>

            </ol>
        </section>

        <section class="content">

                <div class="box box-primary">
                    <div class="box-header with border">
                        <h3 class="box-title" style="margin-bottom:15px">Products</h3>
                    <form action="{{route('dashboard.products.index')}}" method="get" >
                            <div class="row ">
                                <div class="col-md-4">
                                 <input type="text" name="search" class="form-control" placeholder="search">

                                </div>


                                <div class="col-md-4">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>Search</button>
                                   
                                        <a href="{{route('dashboard.products.create')}}" class="btn btn-primary"><i class="fa fa-plus"></i>Add Product</a>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="box-body">
                       @if($products->count()>0)
                       <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Category</th>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Size</th>
                                    <th>colors</th>
                                    <th>Price</th>
                                    <th>stock</th>
                                
                                    <th>@lang('Action')</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($products as $index=>$product )
                                    <tr>
                                    <td>{{$index + 1}}</td>
                                    <td>{{$product->category->name}}</td>
                                    <td>{{$product->code}}</td>
                                    <td>{{$product->name}}</td>
                                    <td><img src="{{$product->image_path}}" style="width: 100px;" class="img-thumbnail"></td>
                                    <td>
                                    @foreach ($product->sizes as $size)
                                    {{$size->size}}
                
                                    @endforeach
                                    </td>
                                    <td>
                                        @foreach ( $product->colors as $color)
                                        {{str_replace('','/',$color->color)}}
                                            
                                        @endforeach
                                        </td>
                                 
                                    <td>{{$product->sale_price}}</td>
                                    <td>{{$product->stock}}</td>

                                    <td>
                                   
                                    <a href="{{route('dashboard.products.edit',$product->id)}}" class="btn btn-info btn-sm"><i class="fa fa-edit"></i>Edit</a>
                                    
                                    
                                       <form action="{{route('dashboard.products.destroy',$product->id)}}"  method="POST" style="display:inline">
                                            {{csrf_field()}}
                                            {{method_field('delete')}}
                                            <button type="submit" class="btn btn-danger delete btn-sm"><i class="fa fa-trash"></i>Delete</button>
    
                                        </form>
                        
                                   
                                    </td>
                                    </tr>
                                    
                                @endforeach
                            </tbody>
                            
                        </table>
                        
                        {{$products->links()}}
                        @else
                    <h2>Not_products_found</h2>
                    @endif
                
                     </div>
                </div>
        </section>
    </div>
    

@endsection