@extends('layouts.dashboard.app')

@section('content')

    <div class="content-wrapper">

        <section class="content-header">

            <h1>@lang('Products')</h1>

        <ol class="breadcrumb">
            <li><a href="{{route('dashboard.index')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="{{route('dashboard.products.index')}}">Products</a></li>
            <li class="active"> Edit Product</li>
            
        </ol>
        </section>

        <section class="content">

 <div class="box box-primary">
               <div class="box-header">
                   <h3 class="box-title">Edit</h3>
               </div>
               <div class="box-body">
                @include('partials._errors')
                
               <form action="{{route('dashboard.products.update',$product->id)}}" method="POST" enctype="multipart/form-data">
                {{csrf_field()}}
                {{method_field('put')}}

                <div class="form-group">
                    <label>Code</label>
                <input type="text" name="code"  class="form-control" value="{{$product->code}}">

                </div>

               
                <div class="form-group">
                        <label>Name</label>
                <input type="text" name="name"  class="form-control" value="{{$product->name}}">
   
                </div>
              
                   
                    
               
            
            {{--image and image preview--}}
            <div class="form-group">
                    <label>Image</label>
                    <input type="file" name="image" placeholder="image" class="form-control image">

            </div>
            <div class="form-group">
            <img src="{{$product->image_path}}" style="width: 100px;" class="img-thumbnail image-preview" alt=""> 

            </div>

            {{--size --}}
            
            <div class="form-group">
                <label>Size</label>
                
                <div class="nav-tabs-custom">
                    @php
                       $sizes=['xxxl','xxl','xl','L','M','S']
                    @endphp
    
                            <div class="tab-content" id="pills-tabContent">
                             
                                
                                 @foreach ($product->sizes as $size)
                                <label><input type="checkbox" name="size[]"  checked >{{$size->size}}</label>    
                                   @endforeach
                                
                                      
                            </div>
                               
                                
                </div>
            </div>

        
        {{--colors --}}
        <div class="form-group">
            <label>Colors</label>
            
            <div class="nav-tabs-custom">
                @php
                   $colors=['All Colors','Black','White','Red','Brown','Other']
                @endphp

                        <div class="tab-content" id="pills-tabContent">
                          @foreach ( $product->colors as $color)
                            <label><input type="checkbox" name="color[]" checked value="{{$color->color}}">{{$color->color}}</label>    
                            @endforeach
                            

                              
                        </div>
                           
                            
            </div>
        </div>
            
    
          {{--price --}}
            <div class="form-group">
                    <label>sale price</label>
                    <input type="number" name="sale_price" step="0.01" value="{{$product->sale_price}}" class="form-control">

            </div>
        {{--stock --}}
            <div class="form-group">
                    <label>stock</label>
                    <input type="number" name="stock"  class="form-control" value="{{$product->stock}}">

            </div>

            


                        <div class="form-group">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i>Update Product</button>
                        </div>
    

              
                

           

            </div> 
        </div>
    </div> 
                </div> <!--end of body-->
           </div>
        </section>
    </div>


@endsection