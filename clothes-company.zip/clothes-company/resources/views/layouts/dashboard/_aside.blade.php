<aside class="main-sidebar">

    <section class="sidebar">

       

     <ul class="sidebar-menu" data-widget="tree">
       
     <li><a href="{{route('dashboard.index')}}"><i class="fa fa-th"></i><span>Dashboard</span></a></li>
     
        <li><a href="{{route('dashboard.products.index')}}"><i class="fa fa-th"></i><span>Products</span></a></li>
       
        <li><a href="{{ route('dashboard.categories.index') }}"><i class="fa fa-book"></i><span>Categories</span></a></li>
     
            
           
            

        </ul>
  
       
    
    </section>

</aside>

